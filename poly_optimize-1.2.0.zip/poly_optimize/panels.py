"""UI panels for PolyOptimize.

The same draw logic is registered in two places: the Modifier Properties
tab (wrench icon, alongside the modifier stack) and the 3D viewport
N-panel. Both read the shared Scene-level settings.

A Basic/Advanced toggle at the top of the panel switches label text
between plain language and standard Blender terminology. Tooltips are
fixed at registration, so they carry both (see properties.py).
"""

from __future__ import annotations

import bpy

from .operators import OBJECT_OT_poly_optimize, SUPPORTED_MODES

# Property/heading/button labels as (basic, advanced) pairs. Only the
# text shown in the panel changes; property names and tooltips do not.
_LABELS: dict[str, tuple[str, str]] = {
    "output_mode": ("Result", "Output"),
    "angle_limit": ("Flatness Sensitivity", "Planar Tolerance"),
    "simplify_boundaries": (
        "Straighten Outlines", "Simplify Region Boundaries"
    ),
    "triangulate": ("Convert to Triangles", "Triangulate Result"),
    "reduction_level": ("Detail Reduction", "Vertex Reduction Level"),
    "use_weld": ("Merge Overlapping Points", "Weld Duplicate Vertices"),
    "weld_distance": ("Merge Distance", "Weld Distance"),
    "preserve_seams": ("Protect Texture Seams", "Preserve UV Seams"),
    "preserve_sharp": ("Protect Sharp Corners", "Preserve Sharp Edges"),
    "preserve_materials": (
        "Protect Color Boundaries", "Preserve Material Borders"
    ),
    "preserve_uv_borders": (
        "Protect Texture Layout", "Preserve UV Borders"
    ),
    "heading_planar": ("Flatten Surfaces", "Planar Merge"),
    "heading_reduce": ("Detail", "Vertex Reduction"),
    "heading_cleanup": ("Tidy Up", "Cleanup"),
    "heading_preserve": ("Protect", "Preserve"),
    "button": ("Simplify Model", "Optimize Polygons"),
}


def _draw(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    settings = context.scene.poly_optimize
    basic = settings.ui_mode == "BASIC"

    def label(key: str) -> str:
        pair = _LABELS[key]
        return pair[0] if basic else pair[1]

    row = layout.row()
    row.prop(settings, "ui_mode", expand=True)

    layout.use_property_split = True
    layout.use_property_decorate = False

    layout.prop(settings, "output_mode", text=label("output_mode"))

    col = layout.column(heading=label("heading_planar"))
    col.prop(settings, "angle_limit", text=label("angle_limit"))
    col.prop(
        settings, "simplify_boundaries", text=label("simplify_boundaries")
    )
    col.prop(settings, "triangulate", text=label("triangulate"))

    col = layout.column(heading=label("heading_reduce"))
    col.prop(
        settings, "reduction_level", text=label("reduction_level"),
        slider=True,
    )
    if settings.reduction_level > 0:
        target = 0.5 ** settings.reduction_level * 100.0
        text = (
            f"Keeps about {target:.1f}% of the detail"
            if basic
            else f"Target ≈ {target:.1f}% of vertices"
        )
        col.label(text=text, icon="INFO")

    col = layout.column(heading=label("heading_cleanup"))
    col.prop(settings, "use_weld", text=label("use_weld"))
    sub = col.column()
    sub.active = settings.use_weld
    sub.prop(settings, "weld_distance", text=label("weld_distance"))

    col = layout.column(heading=label("heading_preserve"))
    col.prop(settings, "preserve_seams", text=label("preserve_seams"))
    col.prop(settings, "preserve_sharp", text=label("preserve_sharp"))
    col.prop(
        settings, "preserve_materials", text=label("preserve_materials")
    )
    col.prop(
        settings, "preserve_uv_borders", text=label("preserve_uv_borders")
    )

    layout.separator()
    if context.mode not in SUPPORTED_MODES:
        layout.label(text="Switch to Object Mode to run", icon="ERROR")
    else:
        layout.label(
            text="Settings apply when you click the button", icon="INFO"
        )
    layout.operator(
        OBJECT_OT_poly_optimize.bl_idname,
        text=label("button"),
        icon="MOD_DECIM",
    )

    obj = context.active_object
    if obj and obj.type == "MESH":
        mesh = obj.data
        box = layout.box()
        box.label(text=f"Active: {obj.name}", icon="MESH_DATA")
        box.label(
            text=(
                f"Verts {len(mesh.vertices):,} · "
                f"Edges {len(mesh.edges):,} · "
                f"Faces {len(mesh.polygons):,}"
            )
        )

    if settings.has_result:
        box = layout.box()
        box.label(text="Last Result", icon="CHECKMARK")
        _stat_row(box, "Verts", settings.last_verts_before,
                  settings.last_verts_after)
        _stat_row(box, "Edges", settings.last_edges_before,
                  settings.last_edges_after)
        _stat_row(box, "Faces", settings.last_faces_before,
                  settings.last_faces_after)


def _stat_row(
    layout: bpy.types.UILayout, label: str, before: int, after: int
) -> None:
    percent = ((before - after) / before * 100.0) if before else 0.0
    layout.label(text=f"{label}: {before:,} → {after:,}  (−{percent:.1f}%)")